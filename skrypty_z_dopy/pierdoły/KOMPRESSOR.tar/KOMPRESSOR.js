// Ten skrypt to wersja wsadowa: przetwarza wszystkie pliki z katalogu "in" po kolei
// Upewnij się, że masz ustawione FFMPEG i FFPROBE zgodnie ze swoją instalacją

const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { spawnSync } = require('child_process');

const FFMPEG = "C:/ffmpeg/bin/ffmpeg.exe";
const FFPROBE = "C:/ffmpeg/bin/ffprobe.exe";

const BASE_DIR = "C:/KOMPRESSOR";
const IN_DIR = path.join(BASE_DIR, "in");
const OUT_DIR = path.join(BASE_DIR, "out");

if (!fs.existsSync(IN_DIR)) fs.mkdirSync(IN_DIR, { recursive: true });
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = query => new Promise(resolve => rl.question(query, a => resolve(a.trim())));

function runCommand(command, args) {
  console.log(`\n>>> ${command} ${args.join(' ')}`);
  const result = spawnSync(command, args, { stdio: 'inherit' });
  if (result.error) throw result.error;
}

function getDuration(filePath) {
  const args = ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', filePath];
  const result = spawnSync(FFPROBE, args, { encoding: 'utf8' });
  return parseFloat(result.stdout);
}

function hasVideo(filePath) {
  const args = ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=index', '-of', 'csv=p=0', filePath];
  const result = spawnSync(FFPROBE, args, { encoding: 'utf8' });
  return result.stdout.trim() !== "";
}

async function main() {
  console.log("=== KOMPRESSOR WSADOWY ===\n");
  const files = fs.readdirSync(IN_DIR).filter(f => fs.lstatSync(path.join(IN_DIR, f)).isFile());
  if (files.length === 0) {
    console.log("Brak plików do kompresji.");
    rl.close();
    return;
  }

  console.log(`Znaleziono ${files.length} plik(ow):\n`);
  files.forEach(f => console.log("- " + f));

  const method = await ask("\nWybierz metodę kompresji (1 = target size, 2 = CRF): ");
  let targetMB, crfValue;

  if (method === "1") {
    const tmb = await ask("Podaj docelowy rozmiar w MB: ");
    targetMB = parseFloat(tmb);
    if (isNaN(targetMB) || targetMB <= 0) {
      console.log("Nieprawidłowy rozmiar!");
      rl.close();
      return;
    }
  } else if (method === "2") {
    crfValue = await ask("Podaj wartość CRF (domyślnie 28): ");
    if (!crfValue) crfValue = "28";
  } else {
    console.log("Nieprawidłowa metoda.");
    rl.close();
    return;
  }

  for (const fileName of files) {
    try {
      const inputPath = path.join(IN_DIR, fileName);
      const videoExists = hasVideo(inputPath);
      const outputExt = videoExists ? ".mp4" : ".mp3";
      const baseName = path.basename(fileName, path.extname(fileName));
      const outputName = `${baseName}_compressed${outputExt}`;
      const outputPath = path.join(OUT_DIR, outputName);
      const duration = getDuration(inputPath);
      const durationSec = Math.floor(duration);

      console.log(`\n>>> Kompresuję: ${fileName}`);

      if (method === "1") {
        const targetBytes = targetMB * 1024 * 1024;
        const totalBits = targetBytes * 8;

        if (videoExists) {
          const audioBitrate = 128000;
          const audioBits = durationSec * audioBitrate;
          let videoBitrateBps = Math.max(300000, Math.floor((totalBits - audioBits) / durationSec));
          const maxrate = Math.floor(videoBitrateBps * 1.5);

          runCommand(FFMPEG, ["-y", "-i", inputPath, "-c:v", "libx264", "-b:v", videoBitrateBps.toString(),
            "-maxrate", maxrate.toString(), "-bufsize", maxrate.toString(), "-preset", "slow",
            "-pass", "1", "-an", "-f", "mp4", "NUL"]);

          runCommand(FFMPEG, ["-y", "-i", inputPath, "-c:v", "libx264", "-b:v", videoBitrateBps.toString(),
            "-maxrate", maxrate.toString(), "-bufsize", maxrate.toString(), "-pass", "2",
            "-preset", "slow", "-c:a", "aac", "-b:a", "128k", outputPath]);

          ["ffmpeg2pass-0.log", "ffmpeg2pass-0.log.mbtree"].forEach(f => fs.existsSync(f) && fs.unlinkSync(f));
        } else {
          const audioBitrate = Math.max(64000, Math.floor(totalBits / durationSec));
          runCommand(FFMPEG, ["-y", "-i", inputPath, "-c:a", "libmp3lame", "-b:a", audioBitrate.toString(), outputPath]);
        }

      } else if (method === "2") {
        if (!videoExists) {
          console.log("Pominięto: CRF nie dotyczy plików audio.");
          continue;
        }
        runCommand(FFMPEG, ["-y", "-i", inputPath, "-c:v", "libx265", "-preset", "slow", "-crf", crfValue,
          "-c:a", "aac", "-b:a", "128k", outputPath]);
      }

      console.log(`Zakończono: ${outputName}`);
    } catch (err) {
      console.error(`Błąd podczas przetwarzania ${fileName}:`, err);
    }
  }
  rl.close();
}

main();
