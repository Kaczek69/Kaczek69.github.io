const fs = require('fs');
const crypto = require('crypto');
const path = require('path');
const readline = require('readline');

const inDir = path.join(__dirname, 'in');
const outDir = path.join(__dirname, 'out');
const ALGORITHM = 'aes-256-cbc';
const IV_LENGTH = 16;

function sha256(text) {
    return crypto.createHash('sha256').update(text).digest('hex');
}

function encryptFile(filePath, password) {
    const fileData = fs.readFileSync(filePath);
    const key = crypto.createHash('sha256').update(password).digest();
    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
    const encrypted = Buffer.concat([iv, cipher.update(fileData), cipher.final()]);

    const hashName = sha256(password).substring(0, 10);
    const outFile = path.join(outDir, `${hashName}_${path.basename(filePath)}.bin`);
    fs.writeFileSync(outFile, encrypted);
    console.log(`🔐 Zaszyfrowano: ${filePath} → ${outFile}`);
}

function decryptFile(filePath, password) {
    const encryptedData = fs.readFileSync(filePath);
    const key = crypto.createHash('sha256').update(password).digest();
    const iv = encryptedData.slice(0, IV_LENGTH);
    const content = encryptedData.slice(IV_LENGTH);
    const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
    const decrypted = Buffer.concat([decipher.update(content), decipher.final()]);

    const outFile = path.join(outDir, `odtworzone_${path.basename(filePath, '.bin')}`);
    fs.writeFileSync(outFile, decrypted);
    console.log(`🔓 Odszyfrowano: ${filePath} → ${outFile}`);
}

function prompt(question) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(resolve => rl.question(question, ans => { rl.close(); resolve(ans); }));
}

(async () => {
    if (!fs.existsSync(inDir)) fs.mkdirSync(inDir);
    if (!fs.existsSync(outDir)) fs.mkdirSync(outDir);

    console.log("=== ENIGMA ===");
    console.log("1. Szyfruj pliki z /in");
    console.log("2. Deszyfruj pliki z /in");

    const option = await prompt("Wybierz opcję (1/2): ");
    const password = await prompt("Podaj hasło: ");

    const files = fs.readdirSync(inDir);

    if (option === '1') {
        files.forEach(file => {
            const fullPath = path.join(inDir, file);
            if (fs.lstatSync(fullPath).isFile()) {
                encryptFile(fullPath, password);
            }
        });
    } else if (option === '2') {
        files.forEach(file => {
            const fullPath = path.join(inDir, file);
            if (fs.lstatSync(fullPath).isFile() && path.extname(file) === '.bin') {
                try {
                    decryptFile(fullPath, password);
                } catch (e) {
                    console.log(`❌ Błąd deszyfrowania pliku: ${file} (może złe hasło?)`);
                }
            }
        });
    } else {
        console.log("❌ Nieprawidłowa opcja.");
    }

    console.log("✅ Zakończono.");
})();
